<?php

session_start();
if (!isset($_SESSION['email'])) {
    header('location: ./index.php');
    exit;
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--Bootstrap 5 icons CDN-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <title>Hasta Yönetim Paneli</title>

    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    

  <section class="p-3">
    <div class="modal-header">
        <h4 class="modal-title">Hasta Profili</h4>
    </div>

    <div class="modal-body">

        <form action="controller.php" method="post" id="myForm">



            <div class="inputField">
                <div>
                    <label for="ad">Ad:</label>
                    <input type="text" name="ad" id="ad" required>
                </div>
                <div>
                    <label for="soyad">Soyad:</label>
                    <input type="text" name="soyad" id="soyad" required>
                </div>
                <input type="hidden" name="function_to" value="yes">
                <input type="hidden" name="function_to_call" value="hastaprofilguncelleme">
                <input type="hidden" name="userid" id="userid" value="<?= $_SESSION['userid']; ?>">

            </div>

        </form>
    </div>

    <div class="modal-footer">
            
    <button  id="hastasil" class="btn btn-danger submit" onclick="hesapsil(<?= $_SESSION['userid']; ?>)" class="active">Hesap Sil</button>

        <a href="/patienthome.php" class="btn btn-secondary submit">Geri Gel</a>

        <button type="submit" form="myForm" class="btn btn-primary submit">Kaydet</button>
    </div>

</section>

    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script>
        function hesapsil(hastaid) {
            console.log(hastaid);
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                type : "hastasil",
                hastaid : hastaid
            },
            success: function(result) {
                alert('error');
            },
            error: function(result) {
                alert('error');
            }
            });
        }

    </script>
  </body>
</html>