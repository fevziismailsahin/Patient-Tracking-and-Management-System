<?php
class Doktor {
    public $ad;
    public $soyad;
    public $uzamnlikalani;
    public $calistigihastane;



    function __construct($ad, $soyad, $uzamnlikalani, $calistigihastane) {
        $this->ad = $ad;
        $this->soyad = $soyad;
        $this->uzmanlikalani = $uzamnlikalani;
        $this->calistigihastane = $calistigihastane;
    }
}



?>