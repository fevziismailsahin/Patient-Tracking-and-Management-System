<?php
class TıbbiRapor {
    public $tarihi;
    public $icerigi;
    public $hastaid;
    public $doktorid;

    function __construct($tarihi, $icerigi, $hastaid, $doktorid) {
        $this->tarihi = $tarihi;
        $this->icerigi = $icerigi;
        $this->hastaid = $hastaid;
        $this->doktorid = $doktorid;

    }
}

?>