 
 <?php 
  
 class Veritabani { 
     public $hastalar = array(); 
     public $doktorlar = array(); 
     public $yoneticiler = array(); 



     function yoneticihastaekle($hasta) { 
         $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
  
         //$query = "INSERT INTO hastalar (ad, soyad, dogumtarihi, cinsiyet, telefonnumarasi, adres) VALUES ($1, $2, $3, $4, $5, $6)"; 
         $result = pg_query_params($dbconn, 'INSERT INTO hastalar (ad, soyad, dogumtarihi, cinsiyet, telefonnumarasi, adres) VALUES ($1, $2, $3, $4, $5, $6)', array($hasta->ad, $hasta->soyad, $hasta->dogumtarihi, $hasta->cinsiyet, $hasta->telefonnumarasi, $hasta->adres)); 
  
  
     } 
     function tumdoktorlar() { 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
 
        //$query = "INSERT INTO hastalar (ad, soyad, dogumtarihi, cinsiyet, telefonnumarasi, adres) VALUES ($1, $2, $3, $4, $5, $6)"; 
        $result = pg_query($dbconn, 'SELECT * FROM doktorlar d');
        $rows = pg_fetch_all($result); 
        
        return $rows;
 
    } 
     function yoneticidoktorekle($doktor) { 
         $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
  
         //$query = "INSERT INTO doktorlar (ad, soyad, uzmanlikalani, calistigihastan, telefonnumarasi, adres) VALUES ($1, $2, $3, $4, $5, $6)"; 
         $result = pg_query_params($dbconn, 'INSERT INTO doktorlar (ad, soyad, uzmanlikalani, calistigihastane) VALUES ($1, $2, $3, $4)', array($doktor->ad, $doktor->soyad, $doktor->uzmanlikalani, $doktor->calistigihastane));     
     } 
  
     function yoneticihastasil ($hasta2) { 
         if ($hasta2 > 0){ 
             $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
             $result = pg_query_params($dbconn, 'DELETE FROM hastalar WHERE id = $1', array($hasta2)); 
         } 
     }  
  
     function yoneticidoktorsil ($doktor2) {
        if ($doktor2 > 0){ 
            $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
            $result = pg_query_params($dbconn, 'DELETE FROM doktorlar d WHERE d.id = $1 AND IF d.id NOT IN (SELECT r.doktorid FROM randevular r)', array($doktor2)); 
        } 
    }  
 
    function hastarandevualma ($randevu) { 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
 
        //$query = "INSERT INTO hastalar (ad, soyad, dogumtarihi, cinsiyet, telefonnumarasi, adres) VALUES ($1, $2, $3, $4, $5, $6)"; 
        $result = pg_query_params($dbconn, 'INSERT INTO randevular (tarihi, saati, hastaid, doktorid) VALUES ($1, $2, $3, $4)', array($randevu->ad, $randevu->soyad, $randevu->dogumtarihi, $randevu->cinsiyet)); 
 
    } 
 
    function hastarandevuiptali ($randevu2) { 
        if ($randevu2 > 0){ 
            $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
            $result = pg_query_params($dbconn, 'UPDATE randevular SET canceled = NOW() WHERE id = $1', array($randevu2)); 
        } 
    } 
 
    function doktortıbbiraporekle ($tıbbirapor) { 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
 
        //$query = "INSERT INTO doktorlar (ad, soyad, uzmanlikalani, calistigihastan, telefonnumarasi, adres) VALUES ($1, $2, $3, $4, $5, $6)"; 
        $result = pg_query_params($dbconn, 'INSERT INTO tıbbiraporlar (tarihi, icerigi, hastaid, doktorid) VALUES ($1, $2, $3, $4)', array($tıbbirapor->tarihi, $tıbbirapor->icerigi, $tıbbirapor->hastaid, $tıbbirapor->doktorid));     
    } 
 
    function yoneticihastaguncelleme ($hastaid, $hastauserid, $hasta3){ 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        //$query = "INSERT INTO doktorlar (ad, soyad, uzmanlikalani, calistigihastan, telefonnumarasi, adres) VALUES ($1, $2, $3, $4, $5, $6)"; 
        $result = pg_query_params($dbconn, 'UPDATE hastalar SET ad = $1, soyad =$2, dogumtarihi = $3, cinsiyet = $4, telefonnumarasi = $5, adres = $6) WHERE id = $8', array($hasta3->ad, $hasta3->soyad, $hasta3->dogumtarihi, $hasta3->cinsiyet, $hasta3->telefonnumarasi, $hasta3->adres, $hastaid));     
    }  
 
 
    function yoneticidoktorguncelleme ($doktorid, $doktor4){ 
        $query = "UPDATE doktorlar SET ad = $1, soyad = $2, uzmanlikalani = $3, calistigihastane = $4 WHERE id = $5";  
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 

        $result = pg_query_params($dbconn, "UPDATE doktorlar SET ad = $1, soyad = $2, uzmanlikalani = $3, calistigihastane = $4 WHERE id = $5", array($doktor4->ad, $doktor4->soyad, $doktor4->uzmanlikalani, $doktor4->calistigihastane, $doktorid));
         
    } 
 
 
    function hastarandevuguncelleme ($tıbbiraporid, $tıbbirapor4){ 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
 
        $query = "UPDATE randevular SET tarihi = $1, saati = $2, hastaid = $3, doktorid = $4";  
  
        $result = pg_query_params($dbconn, "UPDATE randevular SET tarihi = $1, saati = $2, hastaid = $3, doktorid = $4 WHERE id = $5", array($tıbbirapor4->tarihi, $tıbbirapor4->saati, $tıbbirapor4->hastaid, $tıbbirapor4->doktorid, $tıbbiraporid)); 
    }  
 
    function doktortıbbiraporguncelleme ($tıbbiraporid, $tıbbirapor4){ 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        $result = pg_query_params($dbconn, "UPDATE tıbbiraporlar SET tarihi = $1, icerigi = $2, hastaid = $3, doktorid = $4 WHERE id = $5", array($tıbbirapor4->tarihi, $tıbbirapor4->icerigi, $tıbbirapor4->uzmanlikalani, $tıbbirapor4->randevuid, $tıbbiraporid)); 
         
        $resultbildirim = pg_query_params($dbconn, "INSERT INTO bildirimler (message, isseen) VALUES ('Yeni raporunuz yüklendi.', '0')");  
    } 
     
 
    function doktorHastaGoster($userid){  
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        
        $query = pg_query_params($dbconn, 'SELECT d.id FROM doktorlar d LEFT JOIN users u ON u.id = d.userid WHERE  u.id = $1', array($userid)); 
        $doktorid = pg_fetch_assoc($query);
        
        $result = pg_query_params($dbconn, " SELECT * FROM hastalar h   
        INNER JOIN randevular r ON r.hastaid = h.id   
        INNER JOIN doktorlar d ON d.id = r.doktorid   
        INNER JOIN tibbiraporlar t ON t.randevuid = r.id  
        WHERE d.id = $1", array(intval($doktorid['id'])));  
        $rows = pg_fetch_all($result); 
        
        return $rows;  

    }  

    function doktorrandevugoster($userid){  
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        
        $query = pg_query_params($dbconn, 'SELECT d.id FROM doktorlar d LEFT JOIN users u ON u.id = d.userid WHERE  u.id = $1', array($userid)); 
        $doktorid = pg_fetch_assoc($query);

        $result = pg_query_params($dbconn, " SELECT r.id, r.randevutarihi, r.randevusaati, h.ad AS hastaad FROM randevular r
        INNER JOIN hastalar h ON h.id = r.hastaid   
        INNER JOIN doktorlar d ON d.id = r.doktorid   
        WHERE d.id = $1 and r.canceled is null", array(intval($doktorid['id'])));  
        $rows = pg_fetch_all($result); 

        return $rows;  
        
    }
    
    function doktorhastalargoster($userid){  
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        
        $query = pg_query_params($dbconn, 'SELECT d.id FROM doktorlar d LEFT JOIN users u ON u.id = d.userid WHERE  u.id = $1', array($userid)); 
        $doktorid = pg_fetch_assoc($query);

        $result = pg_query_params($dbconn, " SELECT h.* FROM hastalar h
        INNER JOIN randevular r ON r.hastaid = h.id
        INNER JOIN doktorlar d ON d.id = r.doktorid   
        WHERE d.id = $1 and r.canceled is null", array(intval($doktorid['id'])));  
        $rows = pg_fetch_all($result); 

        return $rows;  
        
    }
    function doktorraporgoster($userid){  
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        
        $query = pg_query_params($dbconn, 'SELECT d.id FROM doktorlar d LEFT JOIN users u ON u.id = d.userid WHERE  u.id = $1', array($userid)); 
        $doktorid = pg_fetch_assoc($query);

        $result = pg_query_params($dbconn, " SELECT t.*, t.id AS raporid, r.*, h.ad AS hastaad, h.soyad AS hastasoyad FROM tibbiraporlar t
        LEFT JOIN randevular r ON r.id = t.randevuid 
        INNER JOIN hastalar h ON h.id = r.hastaid   
        INNER JOIN doktorlar d ON d.id = r.doktorid 
        WHERE d.id = $1 and r.canceled is null", array(intval($doktorid['id'])));  
        $rows = pg_fetch_all($result); 

        return $rows;  
        
    } 

    function hastaraporlarigoster($userid) {  
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 

        $query = pg_query_params($dbconn, 'SELECT h.id FROM hastalar h LEFT JOIN users u ON u.id = h.userid WHERE  u.id = $1', array($userid)); 
        $hastaid = pg_fetch_assoc($query);

        $result = pg_query_params($dbconn,"  
        SELECT t.*, r.* FROM tibbiraporlar t LEFT JOIN randevular r ON t.randevuid = r.id 
        WHERE t.hastaid = $1", array(intval($hastaid['id'])));


        $rows = pg_fetch_all($result); 

        return $rows;      
    }
    function hastabildirimlerigoster($userid) {  
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 

        $query = pg_query_params($dbconn, 'SELECT h.id FROM hastalar h LEFT JOIN users u ON u.id = h.userid WHERE  u.id = $1', array($userid)); 
        $hastaid = pg_fetch_assoc($query);

        $bildirimler = pg_query_params($dbconn,"  
        SELECT * FROM bildirimler b  
        INNER JOIN tibbiraporlar t ON t.id = b.tibbiraporid 
        INNER JOIN hastalar h ON h.id = t.hastaid 
        WHERE h.id = $1 AND b.isseen = 0", array(intval($hastaid['id']))); 

        $rows = pg_fetch_all($bildirimler); 

        return $rows;      
    }
    function bildirimleriisaretle($bildirimid) {
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
 
  
        $result = pg_query_params($dbconn, "UPDATE bildirimler SET isseen = 1 WHERE id = $1", array($bildirimid)); 
    
    }

    function hastarandevugoster($userid) {  
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 

        $query = pg_query_params($dbconn, 'SELECT h.id FROM hastalar h LEFT JOIN users u ON u.id = h.userid WHERE  u.id = $1', array($userid)); 
        $hastaid = pg_fetch_assoc($query);

        $result = pg_query_params($dbconn,"  
        SELECT r.*, d.ad FROM randevular r 
        INNER JOIN doktorlar d ON d.id = r.doktorid
        WHERE r.hastaid = $1 and r.canceled is null", array(intval($hastaid['id'])));  


        $rows = pg_fetch_all($result); 

        return $rows;      
    } 
 
    function hastaprofiligoster ($hastaid){ 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        $result = pg_query_params($dbconn, "SELECT * from user u LEFT JOIN hastalar h ON h.userid = u.id WHERE h.id = $1", array($hastaid)); 
        return $result; 
 
    } 
 
    function doktorprofiligoster ($userid){ 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        
        
   
        $result = pg_query_params($dbconn, "SELECT u.*, d.*, d.id AS doktorid from users u LEFT JOIN doktorlar d ON d.userid = u.id WHERE u.id = $1", array($userid)); 
        $rows = pg_fetch_all($result); 
        return $rows; 
    } 
    function raporbilgilerigoster ($raporid){ 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        
        
   
        $result = pg_query_params($dbconn, "SELECT r.* from tibbiraporlar r WHERE r.id = $1", array($raporid)); 
        $rows = pg_fetch_all($result); 
        return $rows; 
    } 
    function randevubilgilerigoster ($randevuid){ 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        
        
   
        $result = pg_query_params($dbconn, "SELECT r.* from randevular r WHERE r.id = $1", array($randevuid)); 
        $rows = pg_fetch_all($result); 
        return $rows; 
    } 
 
    function yoneticiprofiligoster ($yoneticiid){ 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        $result = pg_query_params($dbconn, "SELECT * from user u LEFT JOIN yonetici y ON y.userid = u.id WHERE y.id = $1", array($yoneticiid)); 
        return $result; 
    } 
 
    function yoneticihastalarigoster () { 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        $result = pg_query($dbconn, 'SELECT * FROM hastalar'); 
        $rows = pg_fetch_all($result); 
        return $rows; 
    } 
 
    function yoneticidoktorlarigoster () { 
        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        $result = pg_query($dbconn, 'SELECT * FROM doktorlar'); 
        $rows = pg_fetch_all($result); 
        return $rows; 
    }  
 
}
if($_POST) {
    if ($_POST['type']) {

        if ($_POST['type'] == 'randevuekle') {
            $hastaid = $_POST['hastaid'];
            $doktorid = $_POST['doktorid'];
            $randevusaati = $_POST['randevusaati'];
            $randevugunu = $_POST['randevugunu'];
            
            $tarih = new DateTime($randevugunu);

            $simdi = new DateTime();

            if ($tarih > $simdi) {
                $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
 
                //$query = "INSERT INTO hastalar (ad, soyad, dogumtarihi, cinsiyet, telefonnumarasi, adres) VALUES ($1, $2, $3, $4, $5, $6)"; 
                $result = pg_query_params($dbconn, 'INSERT INTO randevular (randevutarihi, randevusaati, hastaid, doktorid) VALUES ($1, $2, $3, $4)', array($randevugunu, $randevusaati, intval($hastaid), intval($doktorid))); 
              
                // Başarılı bir yanıt döndür
                echo json_encode(['status' => 'ok', 'message' => 'its ok']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Seçilen tarih, şimdiki zamandan öncedir veya şimdiki zamandır']);

            }

            
        }
        if ($_POST['type'] == 'randevuiptal') {
            $randevuid = $_POST['randevuid'];
            if ($randevuid > 0){ 
                $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
                $result = pg_query_params($dbconn, 'UPDATE randevular SET canceled = NOW() WHERE id = $1', array($randevuid)); 
            } 
        }
        if ($_POST['type'] == 'hastasil') {
            $hastaid = $_POST['hastaid'];
            $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
            $result = pg_query_params($dbconn, 'DELETE FROM hastalar h WHERE h.userid = $1', array(intval($hastaid))); 
            
        }
        if ($_POST['type'] == 'raporsil') {
            $raporid = $_POST['raporid'];
                $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
                $result = pg_query_params($dbconn, 'DELETE FROM tibbiraporlar t WHERE id = $1', array($raporid)); 
            
        }
        if ($_POST['type'] == 'doktorsil') {
            $doktorid = $_POST['doktorid'];
                $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
                $query = pg_query_params($dbconn, 'SELECT r.id FROM randevular r LEFT JOIN doktorlar d ON d.id = r.doktorid WHERE d.id = $1', array($doktorid)); 
                $randevuid = pg_fetch_assoc($query);
                if(!$randevuid){
                    $result = pg_query_params($dbconn, 'DELETE FROM doktorlar WHERE id = $1', array($doktorid)); 
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Seçilen tarih, şimdiki zamandan öncedir veya şimdiki zamandır']);

                }
        }
        if ($_POST['type'] == 'raporekle') {
            $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 

            $raportarihi = $_POST['raportarihi'];
            $userid = $_POST['userid'];
            $randevuid = $_POST['randevuid'];
            $raporicerigi = $_POST['raporicerigi'];
 
      
            $query = pg_query_params($dbconn, 'SELECT d.id FROM doktorlar d LEFT JOIN users u ON u.id = d.userid WHERE  u.id = $1', array($userid)); 
            $doktorid = pg_fetch_assoc($query);

            $query = pg_query_params($dbconn, 'SELECT h.id FROM hastalar h LEFT JOIN randevular r ON r.hastaid = h.id WHERE r.id = $1', array($randevuid)); 
            $hastaid = pg_fetch_assoc($query);
            

            $result = pg_query_params($dbconn, 'INSERT INTO tibbiraporlar (raportarihi, raporicerigi, hastaid, doktorid, randevuid) VALUES ($1, $2, $3, $4)', array($raportarihi, $raporicerigi, intval($hastaid), intval($doktorid), $randevuid));    
            
            $query = pg_query($dbconn, 'SELECT max(t.id) FROM tibbiraporlar t'); 
            $raporidson = pg_fetch_row($query); 
            
            $result = pg_query_params($dbconn, 'INSERT INTO bildirimler (message, isseen, tibbiraporid) VALUES ($1, $2, $3)', array("Yeni raporunuz yüklenmiştir", 0, intval($raporidson[0])));     
     
            echo json_encode(['status' => 'ok', 'message' => 'its ok']);

        }


        if ($_POST['type'] == 'hastaekle') {
            $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 

            $ad = $_POST['ad'];
            $soyad = $_POST['soyad'];
            $dogumtarihi = $_POST['dogumtarihi'];
            $telefonnumarasi = $_POST['telefonnumarasi'];
            $adres = $_POST['adres'];
            $cinsiyet = $_POST['cinsiyet'];
            $email = $_POST['email'];
            $sifre = $_POST['sifre'];

            /*var_dump($ad);
            var_dump($soyad);
            var_dump($dogumtarihi);
            var_dump($telefonnumarasi);
             die();*/
             $result = pg_query_params($dbconn, 'INSERT INTO users (email, password) VALUES ($1, $2)', array($email, $sifre));     

             $query = pg_query($dbconn, 'SELECT max(u.id) FROM users u'); 
             $hastaid = pg_fetch_row($query);

             $result = pg_query_params($dbconn, 'INSERT INTO hastalar (ad, soyad, dogumtarihi, cinsiyet, telefonnumarasi, adres, userid) VALUES ($1, $2, $3, $4, $5, $6, $7)', array($ad, $soyad, $dogumtarihi, $cinsiyet, $telefonnumarasi, $adres, intval($hastaid[0])));     
            echo json_encode(['status' => 'ok', 'message' => 'its ok']);

        }
        if ($_POST['type'] == 'doktorekle') {
            $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 

            $ad = $_POST['ad'];
            $soyad = $_POST['soyad'];
            $uzmanlikalani = $_POST['uzmanlikalani'];
            $calistigihastane = $_POST['calistigihastane'];
            $email = $_POST['email'];
            $sifre = $_POST['sifre'];

            /*var_dump($ad);
            var_dump($soyad);
            var_dump($dogumtarihi);
            var_dump($telefonnumarasi);
             die();*/
             $result = pg_query_params($dbconn, 'INSERT INTO users (email, password) VALUES ($1, $2)', array($email, $sifre));     

             $query = pg_query($dbconn, 'SELECT max(u.id) FROM users u'); 
             $doktorid = pg_fetch_row($query);

             $result = pg_query_params($dbconn, 'INSERT INTO doktorlar (ad, soyad, uzmanlikalani, calistigihastane, userid) VALUES ($1, $2, $3, $4, $5)', array($ad, $soyad, $uzmanlikalani, $calistigihastane, intval($doktorid[0])));     
            echo json_encode(['status' => 'ok', 'message' => 'its ok']);

        }

    } 
    }

 if($_POST){
if ($_POST['function_to'] == 'yes') {
    $function_to_call = $_POST['function_to_call'];
   


    if ($function_to_call == 'yoneticiprofilguncelleme') {
        $email = $_POST['email'];
        $ad = $_POST['ad'];
        $soyad = $_POST['soyad'];

        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        $result = pg_query_params($dbconn, 'SELECT y.id FROM yonetici y LEFT JOIN users u ON u.id = y.userid WHERE  u.email = $1', array($email)); 
        $yoneticiid = pg_fetch_assoc($result);

        $result = pg_query_params($dbconn, "UPDATE yonetici y SET ad = $1, soyad = $2 WHERE y.id = $3", array($ad, $soyad, intval($yoneticiid['id']))); 
        header("Location: ./yoneticiprofil.php"); 
    }
    if ($function_to_call == 'doktorprofilguncelleme') {
        $userid = $_POST['userid'];
        $ad = $_POST['ad'];
        $soyad = $_POST['soyad'];
        $uzmanlikalani = $_POST['uzmanlikalani'];
        $calistigihastane = $_POST['calistigihastane'];

        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        $result = pg_query_params($dbconn, 'SELECT d.id FROM doktorlar d LEFT JOIN users u ON u.id = d.userid WHERE u.id = $1', array(intval($userid))); 
        $doktorid = pg_fetch_assoc($result);

        $result = pg_query_params($dbconn, "UPDATE doktorlar d SET ad = $1, soyad = $2, uzmanlikalani = $3, calistigihastane = $4 WHERE d.id = $5", array($ad, $soyad, $uzmanlikalani, $calistigihastane, intval($doktorid['id']))); 
        header("Location: ./doctorhome.php"); 
    }
    if ($function_to_call == 'hastaprofilguncelleme') {
        $userid = $_POST['userid'];
        $ad = $_POST['ad'];
        $soyad = $_POST['soyad'];


        $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
        $result = pg_query_params($dbconn, 'SELECT h.id FROM hastalar h LEFT JOIN users u ON u.id = h.userid WHERE u.id = $1', array(intval($userid))); 
        $hastaid = pg_fetch_assoc($result);

        $result = pg_query_params($dbconn, "UPDATE hastalar h SET ad = $1, soyad = $2 WHERE h.id = $3", array($ad, $soyad, intval($hastaid['id']))); 
        header("Location: ./patienthome.php"); 
    }
    if ($function_to_call == 'raporbilgileriguncelleme') {
        $raportarihi = $_POST['raportarihi'];
        $raporicerigi = $_POST['raporicerigi'];
        $raporid = $_POST['raporid'];

        if ($raporid > 0){ 
            $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
            $result = pg_query_params($dbconn, 'UPDATE tibbiraporlar t SET raportarihi = $1, raporicerigi = $2 WHERE t.id = $3', array($raportarihi, $raporicerigi, $raporid)); 
            header("Location: ./doctorhome.php"); 
        }

    }
    if ($function_to_call == 'randevubilgileriguncelleme') {
        $randevutarihi = $_POST['randevutarihi'];
        $randevusaati = $_POST['randevusaati'];
        $randevuid = $_POST['randevuid'];

        if ($randevuid > 0){ 
            $dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
            $result = pg_query_params($dbconn, 'UPDATE randevular r SET randevutarihi = $1, randevusaati = $2 WHERE r.id = $3', array($randevutarihi, $randevusaati, $randevuid)); 
            header("Location: ./patienthome.php"); 
        }

    }
}

 }

?>