<?php

class Randevu {
    public $tarihi;
    public $saati;
    public $hastaid;
    public $doktorid;

    function __construct($tarihi, $saati, $hastaid, $doktorid) {
        $this->tarihi = $tarihi;
        $this->saati = $saati;
        $this->hastaid = $hastaid;
        $this->doktorid = $doktorid;

    }
}
?>