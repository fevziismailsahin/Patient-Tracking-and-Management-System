<?php
class Yonetici {
    public $ad;
    public $soyad;

    function __construct($ad, $soyad) {
        $this->ad = $ad;
        $this->soyad = $soyad;
    }
}



?>