 
<?php 
 
session_start(); 
 
   
include_once 'hasta.php'; 
include_once 'doktor.php'; 
include_once 'controller.php'; 
 

if (!isset($_POST['submit'])) { 
  header('location: ./index.php'); 
  exit; 
} 
 
// PostgreSQL veritabanı bağlantısı 
$dbconn = pg_connect("host=localhost dbname=projlab user=postgres password=135720"); 
 
$username = $_POST['username']; 
$password = $_POST['password']; 
 
$query = "SELECT u.*, h.id AS hastaid FROM users u LEFT JOIN hastalar h ON h.userid = u.id WHERE email='$username' AND password='$password'"; 
 
$result = pg_query($dbconn, $query); 
$users_num = pg_num_rows($result); 
 
if ($users_num < 1) { 
  $_SESSION['login_failed'] = true; 
  header('location: ./index.php'); 
  exit; 
} 
 
$user = pg_fetch_assoc($result); 
$_SESSION['email'] = $user['email']; 
$_SESSION['userid'] = intval($user['id']); 
$_SESSION['hastaid'] = intval($user['hastaid']); 



$admintext = "admin"; 
$patienttext = "patient"; 
$doctortext = "doctor"; 
 
if (strpos($_SESSION['email'], $admintext) !== false) { 
  $veritabani = new Veritabani(); 

  $tumhastalar = $veritabani->yoneticihastalarigoster(); 
$tumdoktorlar = $veritabani->yoneticidoktorlarigoster(); 

  $_SESSION['tumhastalar'] = $tumhastalar; 
  $_SESSION['tumdoktorlar'] = $tumdoktorlar; 
  
  header("Location: ./adminhome.php"); 

} else if (strpos($_SESSION['email'], $patienttext) !== false) { 
  $veritabani = new Veritabani(); 

  $tumraporlar = $veritabani->hastaraporlarigoster($user['id']); 
  $tumbildirimler = $veritabani->hastabildirimlerigoster($user['id']);
  $tumrandevular = $veritabani->hastarandevugoster($user['id']); 

  $_SESSION['tumrandevular'] = $tumrandevular; 
  $_SESSION['tumraporlar'] = $tumraporlar;
  $_SESSION['tumbildirimler'] = $tumbildirimler; 
  header("Location: ./patienthome.php"); 

} else if (strpos($_SESSION['email'], $doctortext) !== false) { 
  $veritabani = new Veritabani(); 

  $tumhastalar = $veritabani->doktorHastaGoster($user['id']); 
  $tumrandevular = $veritabani->doktorrandevugoster($user['id']); 

  $_SESSION['tumhastalar'] = $tumhastalar; 
  $_SESSION['tumrandevular'] = $tumrandevular; 

  header("Location: ./doctorhome.php"); 
} 
 
  /* 
  hasta ekleme 
  $hasta1 = new Hasta("Ahmet", "Yılmaz", "05/01/2003", "Erkek", "0560511654", "Test adres"); 
  $veritabani = new Veritabani(); 
  $veritabani->hastaekle($hasta1); 
  */ 
 
  /* 
  $hasta2 = 10; 
  $veritabani->hastasil($hasta2); 
  */ 
  /* 
  $doktor = new Hasta("Ahmet", "Yılmaz", "05/01/2003", "Erkek", "0560511654", "Test adres"); 
  $veritabani = new Veritabani(); 
  $veritabani->doktorekle($doktor); 
  */ 
 /* 
  $doktor2 = 10; 
  $veritabani->doktorsil($doktor2); 
  */ 
 
   /* 
  randevu alma 
  $randevu1 = new Randevu("05/01/2023", "15:00", "10", "15"); 
  $veritabani = new Veritabani(); 
  $veritabani->randevualma($randevu1); 
  */ 
 
  /* 
  randevu iptali 
  $randevu2 = 2; 
   $veritabani = new Veritabani(); 
  $veritabani->randevuiptali($randevu2); 
  */ 
 
   /* 
  tıbbi raporekleme 
  $tıbbirapor1 = new TıbbiRapor("05/01/2023", "icerik", "10", "15"); 
  $veritabani = new Veritabani(); 
  $veritabani->tıbbiraporekle($tıbbirapor1); 
  */ 
exit; 
 
?>