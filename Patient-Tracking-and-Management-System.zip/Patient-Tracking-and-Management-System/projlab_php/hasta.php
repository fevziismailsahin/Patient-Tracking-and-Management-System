<?php
class Hasta {
    public $ad;
    public $soyad;
    public $dogumtarihi;
    public $cinsiyet;
    public $telefonnumarasi;
    public $adres;

    function __construct($ad, $soyad, $dogumtarihi, $cinsiyet, $telefonnumarasi, $adres) {
        $this->ad = $ad;
        $this->soyad = $soyad;
        $this->dogumtarihi = $dogumtarihi;
        $this->cinsiyet = $cinsiyet;
        $this->telefonnumarasi = $telefonnumarasi;
        $this->adres = $adres;
    }
}

?>