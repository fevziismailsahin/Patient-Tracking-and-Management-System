<?php 
class Kullanici {
    public $email;
    

    function __construct($adsoyad, $email) {
        $this->email = $email;
    }
}




?>