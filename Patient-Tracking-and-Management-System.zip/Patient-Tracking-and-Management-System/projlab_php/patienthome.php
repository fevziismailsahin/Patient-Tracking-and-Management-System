<?php

session_start();

if (!isset($_SESSION['email'])) {
  header('location: ./index.php');
  exit;
}

$patienttext = 'patient';
if (strpos($_SESSION['email'], $patienttext) == false) { 

    header("Location: ./error.php"); 
  
}

include_once 'controller.php'; 

$veritabani = new Veritabani(); 

$tumraporlar = $veritabani->hastaraporlarigoster($_SESSION['userid']); 
$tumbildirimler = $veritabani->hastabildirimlerigoster($_SESSION['userid']);
$tumrandevular = $veritabani->hastarandevugoster($_SESSION['userid']); 
$tumdoktorlar = $veritabani->tumdoktorlar();
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--Bootstrap 5 icons CDN-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <title>Hasta Yönetim Paneli</title>

    <link rel="stylesheet" href="style.css">
  </head>
  <body>
 
    <div class="header">
        <a href="#default" class="logo">CompanyLogo</a>
        <div class="header-center ml-4">
            
            <a href="/hastaprofil.php" class="active">Profile Git</a>

        </div>
        <div class="header-right">
            
            <a href="/logout.php" class="active">Çıkış Yap</a>

        </div>
    </div>
    <?php if($tumbildirimler) : ?>
        <?php foreach ($tumbildirimler as $key => $value) { ?>
            <?php $veritabani = new Veritabani(); $bildirimisaretle = $veritabani->bildirimleriisaretle($value['id']); ?>
            <div class="alert">
            <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
            <strong>Bildirim!</strong><?= $value['message'] ?>
            </div>
        <?php } ?>
        
    <?php endif ?>
    <section class="p-3">

        <div class="row">
          <h1>Raporlar</h1>
            
        </div>

        <div class="row">
            <div class="col-12">
                <table class="table table-striped table-hover mt-3 text-center table-bordered">

                    <thead>
                        <tr>
                            <th>Rapor Tarihi</th>
                            <th>Rapor İçeriği</th>
                            <th>Randevu Tarihi</th>
                        </tr>
                    </thead>
                    <tbody >
                      <?php foreach ($tumraporlar as $hasta) :  ?>
                        <tr>
                        <td><?= $hasta['raportarihi'] ?></td>
                        <td><a href="<?= $hasta['raporicerigi'] ?>" >Dosyaya Git</a></td>
                        <td><?= $hasta['randevutarihi'] ?></td>
                        </tr>
                      <?php endforeach ?>
                    
                    </tbody>

                  </table>
            </div>
        </div>

    </section>

    <section class="p-3">

        <div class="row">
          <h1>Randevular</h1>
            <div class="col-12">
                <button class="btn btn-primary newUser"  data-bs-toggle="modal" data-bs-target="#userForm">Yeni Randevu <i class="bi bi-people"></i></button>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <table class="table table-striped table-hover mt-3 text-center table-bordered">

                    <thead>
                        <tr>
                            <th>Randevu Tarihi</th>
                            <th>Randevu Saati</th>
                            <th>Doktor</th>
                            <th>Durum</th>
                        </tr>
                    </thead>
                    <tbody >
                      <?php foreach ($tumrandevular as $hasta) :  ?>
                        <tr>
                        <td><a href="/randevuprofil.php?randevuid=<?php echo $hasta['id'] ?>"><?= $hasta['randevutarihi'] ?></a></td>
                        <td><?= $hasta['randevusaati'] ?></td>
                        <td><?= $hasta['ad'] ?></td>
                        <td><button class="btn btn-danger" onclick="randevuiptal(<?= $hasta['id'] ?>)">İptal Et</button></td>
                      </tr>
                      <?php endforeach ?>
                    
                    </tbody>

                  </table>
            </div>
        </div>

    </section>



    <!--Modal Form-->
    <div class="modal fade" id="userForm">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Randevu Ekle</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <form action="#" id="myForm">

                        <div class="card imgholder">
                            <label for="imgInput" class="upload">
                                <input type="file" name="" id="imgInput">
                                <i class="bi bi-plus-circle-dotted"></i>
                            </label>
                            <img src="./image/Profile Icon.webp" alt="" width="200" height="200" class="img">
                        </div>

                        <div class="inputField">
                            <div>
                                <label for="doktorlar">Doktor:</label>
                                <select name="doktorlar" id="doktorlar">
                                    <?php foreach ($tumdoktorlar as $key => $value) { ?>
                                        <option value=<?= $value['id']; ?>><?= $value['ad'] . ' ' . $value['soyad']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div>
                                <label for="randevusaati">Randevu Saati:</label>
                                <input type="time" name="" id="randevusaati" required>
                            </div>
                        
                            <div>
                                <label for="randevugunu">Randevu Günü:</label>
                                <input type="date" name="" id="randevugunu" required>
                            </div>
                        </div>

                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" form="myForm" id="button2" class="btn btn-primary submit">Kaydet</button>
                </div>
            </div>
        </div>
    </div>

    <!--Read Data Modal-->
    <div class="modal fade" id="readData">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Profile</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <form action="#" id="myForm">

                        <div class="card imgholder">
                            <img src="./image/Profile Icon.webp" alt="" width="200" height="200" class="showImg">
                        </div>

                        <div class="inputField">
                            <div>
                                <label for="name">Name:</label>
                                <input type="text" name="" id="showName" disabled>
                            </div>
                            <div>
                                <label for="age">Age:</label>
                                <input type="number" name="" id="showAge" disabled>
                            </div>
                            <div>
                                <label for="city">City:</label>
                                <input type="text" name="" id="showCity" disabled>
                            </div>
                            <div>
                                <label for="email">E-mail:</label>
                                <input type="email" name="" id="showEmail" disabled>
                            </div>
                            <div>
                                <label for="phone">Number:</label>
                                <input type="text" name="" id="showPhone" minlength="11" maxlength="11" disabled>
                            </div>
                            <div>
                                <label for="post">Post:</label>
                                <input type="text" name="" id="showPost" disabled>
                            </div>
                            <div>
                                <label for="randevugunu">Start Date:</label>
                                <input type="date" name="" id="randevugunu" disabled>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>

    <script>
        $("#button2").click(function(e) {
            e.preventDefault();
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                type : "randevuekle",
                doktorid : $('#doktorlar').val(),
                randevusaati : $('#randevusaati').val(),
                randevugunu : $('#randevugunu').val(),
                hastaid: <?php echo $_SESSION['hastaid']; ?>,
            },
            success: function(result) {
                location.reload();
            },
            error: function(result) {
                alert('error');
            }
            });
        });

        function randevuiptal(randevuid) {
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                type : "randevuiptal",
                randevuid : randevuid
            },
            success: function(result) {
                location.reload();
            },
            error: function(result) {
                alert('error');
            }
            });
        }
       
    </script>
    <script src="app.js"></script>
    <style>
        .alert {
        padding: 20px;
        background-color: #f44336;
        color: white;
        }

        .closebtn {
        margin-left: 15px;
        color: white;
        font-weight: bold;
        float: right;
        font-size: 22px;
        line-height: 20px;
        cursor: pointer;
        transition: 0.3s;
        }

        .closebtn:hover {
        color: black;
        }
        .header {
        overflow: hidden;
        background-color: #f1f1f1;
        padding: 20px 10px;
        }

    /* Style the header links */
    .header a {
    float: left;
    color: black;
    text-align: center;
    padding: 12px;
    text-decoration: none;
    font-size: 18px;
    line-height: 25px;
    border-radius: 4px;
    }

    /* Style the logo link (notice that we set the same value of line-height and font-size to prevent the header to increase when the font gets bigger */
    .header a.logo {
    font-size: 25px;
    font-weight: bold;
    }

    /* Change the background color on mouse-over */
    .header a:hover {
    background-color: #ddd;
    color: black;
    }

    /* Style the active/current link*/
    .header a.active {
    background-color: dodgerblue;
    color: white;
    }

    /* Float the link section to the right */
    .header-right {
    float: right;
    }

    /* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */
    @media screen and (max-width: 500px) {
    .header a {
        float: none;
        display: block;
        text-align: left;
    }
    .header-right {
        float: none;
    }
    }
    </style>
  </body>
</html>