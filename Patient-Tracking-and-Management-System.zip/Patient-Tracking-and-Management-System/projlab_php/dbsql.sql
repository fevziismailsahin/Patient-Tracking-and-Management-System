-- Hastalar tablosu
CREATE TABLE Hastalar (
    id SERIAL PRIMARY KEY,
    ad VARCHAR(50),
    soyad VARCHAR(50),
    dogumtarihi DATE,
    cinsiyet CHAR(1),
    telefonnumarasi VARCHAR(15),
    adres text,
    userid INT,
   	FOREIGN KEY (userid) REFERENCES users (id)
);



-- Doktorlar tablosu
CREATE TABLE Doktorlar (
    id SERIAL PRIMARY KEY,
    ad VARCHAR(50),
    soyad VARCHAR(50),
    uzmanlikalani VARCHAR(50),
    calistigihastane VARCHAR(50),
    userid INT,
    FOREIGN KEY (userid) REFERENCES users (id)
);

-- Yönetici tablosu
CREATE TABLE Yonetici (
    id SERIAL PRIMARY key,
    ad VARCHAR(50),
    soyad VARCHAR(50),
    userid INT,
    FOREIGN KEY (userid) REFERENCES users (id)
);

-- Randevular tablosu
CREATE TABLE Randevular (
    id SERIAL PRIMARY KEY,
    tarihi DATE,
    saati TIME,
    hastaid INT,
    doktorid INT,
    canceled DATE,
    FOREIGN KEY (HastaID) REFERENCES Hastalar (id),
    FOREIGN KEY (DoktorID) REFERENCES Doktorlar (id)
);

-- Tıbbi Raporlar tablosu
CREATE TABLE TibbiRaporlar (
   	id SERIAL PRIMARY KEY,
    tarihi DATE,
    icerigi TEXT,
    hastaid INT,
    doktorid INT,
    randevuid INT,
    FOREIGN KEY (hastaid) REFERENCES Hastalar (id),
    FOREIGN KEY (doktorid) REFERENCES Doktorlar (id),
    FOREIGN KEY (randevuid) REFERENCES Randevular (id)
);


CREATE TABLE Bildirimler (
   	id SERIAL PRIMARY KEY,
    message TEXT,
    hastaid INT,
    isseen INT,
    tibbiraporid INT,
    FOREIGN KEY (tibbiraporid) REFERENCES Tibbiraporlar (id)
);