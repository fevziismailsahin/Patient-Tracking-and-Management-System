<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['type'] == 'randevuekle') {
        $id = $_POST['id'];

    // Başarılı bir yanıt döndür
    echo json_encode(['status' => 'ok']);
    }




} 
?>