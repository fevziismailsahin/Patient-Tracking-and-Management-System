<?php
class Bildirimler {
    public $message;
    public $isseen;
    public $randevuid;



    function __construct($message, $isseen, $randevuid) {
        $this->message = $message;
        $this->isseen = $isseen;
        $this->randevuid = $randevuid;
    }
}



?>