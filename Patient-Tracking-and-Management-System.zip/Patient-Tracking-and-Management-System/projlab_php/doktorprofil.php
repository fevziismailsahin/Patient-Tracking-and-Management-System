<?php

session_start();
if (!isset($_SESSION['email'])) {
    header('location: ./index.php');
    exit;
}

include_once 'controller.php'; 

$veritabani = new Veritabani(); 

$doktorbilgiler = $veritabani->doktorprofiligoster($_SESSION['userid']);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--Bootstrap 5 icons CDN-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <title>Hasta Yönetim Paneli</title>

    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    

  <section class="p-3">
    <div class="modal-header">
        <h4 class="modal-title">Doktor Profili</h4>
    </div>

    <div class="modal-body">

        <form action="controller.php" method="post" id="myForm">

            

            <div class="inputField">
                <div>
                    <label for="ad">Ad:</label>
                    <input type="text" name="ad" placeholder="<?= $doktorbilgiler[0]['ad']; ?>" id="ad" required>
                </div>
                <div>
                    <label for="soyad">Soyad:</label>
                    <input type="text" name="soyad"placeholder="<?= $doktorbilgiler[0]['soyad']; ?>" id="soyad" required>
                </div>
                <div>
                    <label for="uzmanlikalani">Uzmanlık Alanı:</label>
                    <input type="text" name="uzmanlikalani" placeholder="<?= $doktorbilgiler[0]['uzmanlikalani']; ?>" id="uzmanlikalani" required>
                </div>
                <div>
                    <label for="calistigihastane">Çalıştığı Hastane:</label>
                    <input type="text" name="calistigihastane" id="calistigihastane" placeholder="<?= $doktorbilgiler[0]['calistigihastane']; ?>" required>
                </div>
                <input type="hidden" name="function_to" value="yes">
                <input type="hidden" name="function_to_call" value="doktorprofilguncelleme">
                <input type="hidden" name="userid" id="userid" value="<?= $_GET['id'] ?>">

            </div>

        </form>
    </div>

    <div class="modal-footer">
        <a href="/doctorhome.php" class="btn btn-secondary submit">Geri Gel</a>

        <button type="submit" form="myForm" class="btn btn-primary submit">Kaydet</button>
    </div>

</section>




    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

  </body>
</html>