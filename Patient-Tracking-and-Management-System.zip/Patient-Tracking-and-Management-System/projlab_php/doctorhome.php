<?php

session_start();

if (!isset($_SESSION['email'])) {
  header('location: ./index.php');
  exit;
}

$doctortext = 'doctor';
if (strpos($_SESSION['email'], $doctortext) == false) { 

    header("Location: ./error.php"); 
  
}

include_once 'controller.php'; 

$veritabani = new Veritabani(); 

$tumraporlar = $veritabani->doktorraporgoster($_SESSION['userid']); 
$tumrandevular = $veritabani->doktorrandevugoster($_SESSION['userid']);
$tumhastalar = $veritabani->doktorhastalargoster($_SESSION['userid']);
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--Bootstrap 5 icons CDN-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <title>Hasta Yönetim Paneli</title>

    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    
    <div class="header">
        <a href="#default" class="logo">CompanyLogo</a>
        <div class="header-center ml-4">
            
            <a  href="/doktorprofil.php?id=<?php echo $_SESSION['userid']; ?>" class="active">Profile Git</a>

        </div>
        <div class="header-right">
            
            <a href="/logout.php" class="active">Çıkış Yap</a>

        </div>
    </div>
    <section class="p-3">

        <div class="row">
          <h1>Raporlar</h1>
            <div class="col-12">
                <button class="btn btn-primary"  data-bs-toggle="modal" data-bs-target="#userForm">Yeni Rapor <i class="bi bi-people"></i></button>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <table class="table table-striped table-hover mt-3 text-center table-bordered">

                    <thead>
                        <tr>
                            <th>Rapor Tarihi</th>
                            <th>Rapor İçeriği</th>
                            <th>Randevu Tarihi</th>
                            <th>Randevu Saati</th>
                            <th>Hasta</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody >
                      <?php foreach ($tumraporlar as $hasta) :  ?>
                        <tr>
                        <td><a href="/raporprofil.php?raporid=<?php echo $hasta['raporid'] ?>"><?= $hasta['raportarihi'] ?></a></td>
                        <td><a href=<?= $hasta['raporicerigi'] ?>>Dosyaya Git</a></td>
                        <td><?= $hasta['randevutarihi'] ?></td>
                        <td><?= $hasta['randevusaati'] ?></td>
                        <td><?= $hasta['hastaad'] . ' ' . $hasta['hastasoyad'] ?></td>
                        <td><button class="btn btn-danger" onclick="raporsil(<?= $hasta['raporid'] ?>)">Sil</button></td>
                        </tr>
                      <?php endforeach ?>
                    </tbody>

                  </table>
            </div>
        </div>

    </section>
    <section class="p-3">

        <div class="row">
          <h1>Randevular</h1>

        </div>

        <div class="row">
            <div class="col-12">
                <table class="table table-striped table-hover mt-3 text-center table-bordered">

                    <thead>
                        <tr>
                            <th>Randevu Tarihi</th>
                            <th>Randevu Saati</th>
                            <th>Hasta</th>
                        </tr>
                    </thead>
                    <tbody >
                      <?php foreach ($tumrandevular as $hasta) :  ?>
                        <tr>
                        <td><?= $hasta['randevutarihi'] ?></td>
                        <td><?= $hasta['randevusaati'] ?></td>
                        <td><?= $hasta['hastaad'] ?></td>
                        </tr>
                      <?php endforeach ?>
                    
                    </tbody>

                  </table>
            </div>
        </div>

    </section>

    <section class="p-3">

<div class="row">
  <h1>Hastalar</h1>
    
</div>

<div class="row">
    <div class="col-12">
        <table class="table table-striped table-hover mt-3 text-center table-bordered">

            <thead>
                <tr>
                    <th>Rapor Tarihi</th>
                    <th>Rapor İçeriği</th>
                    <th>Randevu Tarihi</th>
                    <th>Randevu Saati</th>
                    <th>Adres</th>
                </tr>
            </thead>
            <tbody >
              <?php foreach ($tumhastalar as $hasta) :  ?>
                <tr>
                <td><?= $hasta['ad'] . ' ' . $hasta['soyad'] ?></td>
                <td><?= $hasta['dogumtarihi'] ?></td>
                <td><?= $hasta['cinsiyet'] ?></td>
                <td><?= $hasta['telefonnumarasi'] ?></td>
                <td><?= $hasta['adres'] ?></td>
                </tr>
              <?php endforeach ?>
            
            </tbody>

          </table>
    </div>
</div>

</section>

    <!--Modal Form-->
    <div class="modal fade" id="userForm">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Rapor Ekle</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <form action="#" id="myForm">



                        <div class="inputField">
                            <div>
                                <label for="raporicerigi">Rapor İçeriği:</label>
                                <input type="text" name="raporicerigi" id="raporicerigi" required>
                            </div>
                            <div>
                                <label for="randevular">Randevular:</label>
                                <select name="randevular" id="randevular">
                                    <?php foreach ($tumrandevular as $key => $value) { ?>
                                        <option value=<?= $value['id']; ?>><?= $value['randevutarihi'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            
                            <div>
                                <label for="raportarihi">Rapor Tarihi:</label>
                                <input type="date" name="raportarihi" id="raportarihi" required>
                            </div>
                        </div>

                    </form>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" form="myForm" id="raporekle" class="btn btn-primary submit">Rapor Ekle</button>
                </div>
            </div>
        </div>
    </div>

    <!--Read Data Modal-->
    <div class="modal fade" id="readData">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Profile</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <form action="#" id="myForm">

                        <div class="card imgholder">
                            <img src="./image/Profile Icon.webp" alt="" width="200" height="200" class="showImg">
                        </div>

                        <div class="inputField">
                        <div>
                                <label for="raporicerigi">Rapor İçeriği:</label>
                                <input type="text" name="raporicerigi" id="raporicerigi" required>
                            </div>
                            <div>
                                <label for="randevular">Randevular:</label>
                                <select name="randevular" id="randevular">
                                    <?php foreach ($tumrandevular as $key => $value) { ?>
                                        <option value=<?= $value['id']; ?>><?= $value['randevutarihi'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            
                            <div>
                                <label for="raportarihi">Rapor Tarihi:</label>
                                <input type="date" name="raportarihi" id="raportarihi" required>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script>
        $("#raporekle").click(function(e) {
            e.preventDefault();
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                type : "raporekle",
                randevuid : $('#randevular').val(),
                raporicerigi : $('#raporicerigi').val(),
                raportarihi : $('#raportarihi').val(),
                userid: <?php echo $_SESSION['userid']; ?>,
            },
            success: function(result) {
                location.reload();
            },
            error: function(result) {
                alert('error');
            }
            });
        });

        function raporsil(raporid) {
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                type : "raporsil",
                raporid : raporid
            },
            success: function(result) {
                location.reload();
            },
            error: function(result) {
                alert('error');
            }
            });
        }
    </script>
    <script src="app.js"></script>
    <style>
        .header {
        overflow: hidden;
        background-color: #f1f1f1;
        padding: 20px 10px;
        }

    /* Style the header links */
    .header a {
    float: left;
    color: black;
    text-align: center;
    padding: 12px;
    text-decoration: none;
    font-size: 18px;
    line-height: 25px;
    border-radius: 4px;
    }

    /* Style the logo link (notice that we set the same value of line-height and font-size to prevent the header to increase when the font gets bigger */
    .header a.logo {
    font-size: 25px;
    font-weight: bold;
    }

    /* Change the background color on mouse-over */
    .header a:hover {
    background-color: #ddd;
    color: black;
    }

    /* Style the active/current link*/
    .header a.active {
    background-color: dodgerblue;
    color: white;
    }

    /* Float the link section to the right */
    .header-right {
    float: right;
    }

    /* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */
    @media screen and (max-width: 500px) {
    .header a {
        float: none;
        display: block;
        text-align: left;
    }
    .header-right {
        float: none;
    }
    }
    </style>
  </body>
</html>