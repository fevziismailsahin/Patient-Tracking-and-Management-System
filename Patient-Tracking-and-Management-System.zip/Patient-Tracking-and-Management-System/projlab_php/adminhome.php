<?php

session_start();

if (!isset($_SESSION['email'])) {
  header('location: ./index.php');
  exit;
}
$admintext = 'admin';
if (strpos($_SESSION['email'], $admintext) == false) { 
    header("Location: ./error.php"); 
}

include_once 'controller.php'; 

$veritabani = new Veritabani(); 

$tumhastalar = $veritabani->yoneticihastalarigoster(); 
$tumdoktorlar = $veritabani->yoneticidoktorlarigoster();

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--Bootstrap 5 icons CDN-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <title>Hasta Yönetim Paneli</title>

    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    
   <div class="header">
        <a href="#default" class="logo">CompanyLogo</a>
        <div class="header-center ml-4">
            
            <a href="/yoneticiprofil.php" class="active">Profile Git</a>

        </div>
        <div class="header-right">
            
            <a href="/logout.php" class="active">Çıkış Yap</a>

        </div>
    </div>
    <section class="p-3">

        <div class="row">
          <h1>Hastalar</h1>
            <div class="col-12">
                <button class="btn btn-primary newUser" data-bs-toggle="modal" data-bs-target="#userForm">Hasta Ekle <i class="bi bi-people"></i></button>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <table class="table table-striped table-hover mt-3 text-center table-bordered">

                    <thead>
                        <tr>
                            <th>Ad</th>
                            <th>Soyad</th>
                            <th>Doğum Tarihi</th>
                            <th>Cinsiyet</th>
                            <th>Telefon Numarası</th>
                            <th>Adres</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody >
                      <?php foreach ($tumhastalar as $hasta) :  ?>
                        <tr>
                        <td><a href="/hastaprofil.php?hastaid=<?php echo $hasta['id'] ?>"><?= $hasta['ad'] ?></a></td>
                        <td><?= $hasta['soyad'] ?></td>
                        <td><?= $hasta['dogumtarihi'] ?></td>
                        <td><?= $hasta['cinsiyet'] ?></td>
                        <td><?= $hasta['telefonnumarasi'] ?></td>
                        <td><?= $hasta['adres'] ?></td>
                        <td><button class="btn btn-danger" onclick="hastasil(<?= $hasta['id'] ?>)">Sil</button></td>
                        </tr>
                      <?php endforeach ?>
                    
                    </tbody>

                  </table>
            </div>
        </div>

    </section>
<section class="p-3">

<div class="row">
  <h1>Doktorlar</h1>
    <div class="col-12">
        <button class="btn btn-primary newUserDoktor" data-bs-toggle="modal" data-bs-target="#userFormDoktor">Doktor Ekle <i class="bi bi-people"></i></button>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <table class="table table-striped table-hover mt-3 text-center table-bordered">

            <thead>
                <tr>
                    <th>Ad</th>
                    <th>Soyad</th>
                    <th>Uzmanlık Alanı</th>
                    <th>Çalıştığı Hastane</th>
                    <th></th>
                </tr>
            </thead>
            <tbody >
              <?php foreach ($tumdoktorlar as $doktor) :  ?>
                <tr>
                <td><a href="/doktorprofil.php?id=<?php echo $doktor['id'] ?>"><?= $doktor['ad'] ?></a></td>
                <td><?= $doktor['soyad'] ?></td>
                <td><?= $doktor['uzmanlikalani'] ?></td>
                <td><?= $doktor['calistigihastane'] ?></td>
                <td><button class="btn btn-danger" onclick="doktorsil(<?= $doktor['id'] ?>)">Sil</button></td>
                </tr>
              <?php endforeach ?>
            
            </tbody>

          </table>
    </div>
</div>

</section>




    <!--Modal Form-->
    <div class="modal fade" id="userForm">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Hasta Ekle</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <form action="#" id="myForm">

                        <div class="card imgholder">
                            <label for="imgInput" class="upload">
                                <input type="file" name="" id="imgInput">
                                <i class="bi bi-plus-circle-dotted"></i>
                            </label>
                            <img src="./image/Profile Icon.webp" alt="" width="200" height="200" class="img">
                        </div>

                        <div class="inputField">
                            <div>
                                <label for="hastaad">Ad:</label>
                                <input type="text" name="hastaad" id="hastaad" required>
                            </div>
                            <div>
                                <label for="hastasoyad">Soyad:</label>
                                <input type="text" name="hastasoyad" id="hastasoyad" required>
                            </div>
                            <div>
                                <label for="adres">Adres:</label>
                                <input type="text" name="adres" id="adres" required>
                            </div>
                            <div>
                                <label for="cinsiyet">Cinsiyet:</label>
                                <input type="text" name="cinsiyet" id="cinsiyet" required>
                            </div>
                            <div>
                                <label for="telefonnumarasi">Telefon Numarası:</label>
                                <input type="number" name="telefonnumarasi"  id="telefonnumarasi" required>
                            </div>
                            <div>
                                <label for="dogumtarihi">Doğum Tarihi:</label>
                                <input type="date" name="dogumtarihi" id="dogumtarihi"  required>
                            </div>
                            <div>
                                <label for="hastaemail">Email:</label>
                                <input type="text" name="hastaemail" id="hastaemail"  required>
                            </div>
                            <div>
                                <label for="hastasifre">Şifre:</label>
                                <input type="password" name="hastasifre" id="hastasifre"  required>
                            </div>
                        </div>

                    </form>
                </div>

                <div class="modal-footer">
                    <input type="hidden" name="function_to" value="no">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" form="myForm" id="hastaekle" class="btn btn-primary submit">Submit</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="userFormDoktor">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Doktor Ekle</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <form action="#" id="myForm">

                        <div class="card imgholder">
                            <label for="imgInput" class="upload">
                                <input type="file" name="" id="imgInput">
                                <i class="bi bi-plus-circle-dotted"></i>
                            </label>
                            <img src="./image/Profile Icon.webp" alt="" width="200" height="200" class="img">
                        </div>

                        <div class="inputField">
                            <div>
                                <label for="doktorad">Ad:</label>
                                <input type="text" name="doktorad" id="doktorad" required>
                            </div>
                            <div>
                                <label for="doktorsoyad">Soyad:</label>
                                <input type="text" name="doktorsoyad" id="doktorsoyad" required>
                            </div>
                            <div>
                                <label for="uzmanlikalani">Uzmanlık Alanı:</label>
                                <input type="text" name="uzmanlikalani" id="uzmanlikalani" required>
                            </div>
                            <div>
                                <label for="calistigihastane">Çalıştığı Hastane:</label>
                                <input type="text" name="calistigihastane" id="calistigihastane" required>
                            </div>
                            <div>
                                <label for="doktoremail">Email:</label>
                                <input type="text" name="doktoremail" id="doktoremail" required>
                            </div>
                            <div>
                                <label for="doktorsifre">Şifre:</label>
                                <input type="password" name="doktorsifre" id="doktorsifre" required>
                            </div>
                        </div>

                    </form>
                </div>

                <div class="modal-footer">
                    <input type="hidden" name="function_to" value="no">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" form="myForm" id="doktorekle" class="btn btn-primary submit">Submit</button>
                </div>
            </div>
        </div>
    </div>


    <!--Read Data Modal-->
    <div class="modal fade" id="readData">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h4 class="modal-title">Profile</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">

                    <form action="#" id="myForm">

                        <div class="card imgholder">
                            <img src="./image/Profile Icon.webp" alt="" width="200" height="200" class="showImg">
                        </div>

                        <div class="inputField">
                            <div>
                                <label for="name">Ad:</label>
                                <input type="text" name="" id="showName" disabled>
                            </div>
                            <div>
                                <label for="age">Age:</label>
                                <input type="number" name="" id="showAge" disabled>
                            </div>
                            <div>
                                <label for="city">City:</label>
                                <input type="text" name="" id="showCity" disabled>
                            </div>
                            <div>
                                <label for="email">E-mail:</label>
                                <input type="email" name="" id="showEmail" disabled>
                            </div>
                            <div>
                                <label for="phone">Number:</label>
                                <input type="text" name="" id="showPhone" minlength="11" maxlength="11" disabled>
                            </div>
                            <div>
                                <label for="post">Post:</label>
                                <input type="text" name="" id="showPost" disabled>
                            </div>
                            <div>
                                <label for="sDate">Start Date:</label>
                                <input type="date" name="" id="showsDate" disabled>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script>
        $("#hastaekle").click(function(e) {
            e.preventDefault();
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                function_to : "no",
                type : "hastaekle",
                ad : $('#hastaad').val(),
                soyad : $('#hastasoyad').val(),
                telefonnumarasi : $('#telefonnumarasi').val(),
                adres : $('#adres').val(),
                cinsiyet : $('#cinsiyet').val(),
                dogumtarihi: $('#dogumtarihi').val(),
                email : $('#hastaemail').val(),
                sifre : $('#hastasifre').val()
            },
            success: function(result) {
                alert('error');
            },
            error: function(result) {
                alert('error');
            }
            });
        });

        $("#doktorekle").click(function(e) {
            e.preventDefault();
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                function_to : "no",
                type : "doktorekle",
                ad : $('#hastaad').val(),
                soyad : $('#hastasoyad').val(),
                uzmanlikalani : $('#uzmanlikalani').val(),
                calistigihastane : $('#calistigihastane').val(),
                email : $('#doktoremail').val(),
                sifre : $('#doktorsifre').val()
            },
            success: function(result) {
                alert('error');
            },
            error: function(result) {
                alert('error');
            }
            });
        });

        function hastasil(hastaid) {
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                type : "hastasil",
                hastaid : hastaid
            },
            success: function(result) {
                location.reload();
            },
            error: function(result) {
                alert('error');
            }
            });
        }
        function doktorsil(doktorid) {
            $.ajax({
            type: "POST",
            url: "/controller.php",
            data: {
                type : "doktorsil",
                doktorid : doktorid
            },
            success: function(result) {
                alert('Bu doktora ait randevu var.');
                
            },
            error: function(result) {
                alert('Bu doktora ait randevu var.');
            }
            });
        }
    </script>
    
    <script src="app.js"></script>
    <style>
        .header {
        overflow: hidden;
        background-color: #f1f1f1;
        padding: 20px 10px;
        }

    /* Style the header links */
    .header a {
    float: left;
    color: black;
    text-align: center;
    padding: 12px;
    text-decoration: none;
    font-size: 18px;
    line-height: 25px;
    border-radius: 4px;
    }

    /* Style the logo link (notice that we set the same value of line-height and font-size to prevent the header to increase when the font gets bigger */
    .header a.logo {
    font-size: 25px;
    font-weight: bold;
    }

    /* Change the background color on mouse-over */
    .header a:hover {
    background-color: #ddd;
    color: black;
    }

    /* Style the active/current link*/
    .header a.active {
    background-color: dodgerblue;
    color: white;
    }

    /* Float the link section to the right */
    .header-right {
    float: right;
    }

    /* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */
    @media screen and (max-width: 500px) {
    .header a {
        float: none;
        display: block;
        text-align: left;
    }
    .header-right {
        float: none;
    }
    }
    </style>
  </body>
</html>